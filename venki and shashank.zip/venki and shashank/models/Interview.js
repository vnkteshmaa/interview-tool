const mongoose = require('mongoose');

const interviewSchema = new mongoose.Schema({
  userEmail: { type: String, required: true },
  scheduledBy: { type: String, required: true }, // admin email
  date: { type: Date, required: true },
  notes: String
});

module.exports = mongoose.model('Interview', interviewSchema); 