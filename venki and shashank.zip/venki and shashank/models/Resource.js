const mongoose = require('mongoose');

const resourceSchema = new mongoose.Schema({
  title: String,
  link: String,
  type: String, // pdf or video
  userEmail: String, // assigned user
  category: String, // tech or commerce
  description: String,
  addedBy: String, // admin email
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Resource', resourceSchema);

// AdminLoginLog model
const adminLoginLogSchema = new mongoose.Schema({
  email: String,
  timestamp: { type: Date, default: Date.now },
  success: Boolean
});
module.exports.AdminLoginLog = mongoose.model('AdminLoginLog', adminLoginLogSchema); 