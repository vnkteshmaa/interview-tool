const express = require('express');
const mongoose = require('mongoose');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const app = express();
const PORT = 4000;
const User = require('./models/User');
const bcrypt = require('bcryptjs');
const ActivityLog = require('./models/ActivityLog');
const Resource = require('./models/Resource');
const { AdminLoginLog } = require('./models/Resource');
const Admin = require('./models/Admin');

// Feedback and Rating Models
const Feedback = mongoose.model('Feedback', new mongoose.Schema({
  userEmail: { type: String, required: true },
  message: { type: String, required: true },
  timestamp: { type: Date, default: Date.now },
  type: { type: String, default: 'feedback' }
}));

const Rating = mongoose.model('Rating', new mongoose.Schema({
  userEmail: { type: String, required: true, unique: true },
  rating: { type: Number, required: true, min: 1, max: 5 },
  timestamp: { type: Date, default: Date.now },
  type: { type: String, default: 'rating' }
}));

// Replace this with your actual MongoDB connection string
const MONGODB_URI = 'mongodb://localhost:27017/myappdb';

mongoose.connect(MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('Connected to MongoDB!'))
.catch((err) => console.error('MongoDB connection error:', err));

app.use(express.static('public'));
app.use(express.json());

// Set up multer for video uploads
const upload = multer({ dest: path.join(__dirname, 'uploads/') });

// Mongoose schema for interview submissions
const interviewSchema = new mongoose.Schema({
  category: String,
  answers: [mongoose.Schema.Types.Mixed],
  videoPath: String,
  createdAt: { type: Date, default: Date.now }
});
const Interview = mongoose.model('Interview', interviewSchema);

// Serve index.html as the default page for root
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Serve other HTML pages
app.get('/home', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'home.html'));
});

app.get('/dashboard', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'dashboard.html'));
});

app.get('/resource', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'resource.html'));
});

app.get('/practice', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'practice.html'));
});

app.get('/interviews', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'interviews.html'));
});

app.get('/settings', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'settings.html'));
});

// Register endpoint
app.post('/api/register', async (req, res) => {
  const { username, email, password } = req.body;
  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = new User({ username, email, password: hashedPassword });
    await user.save();
    await ActivityLog.create({ email, action: 'signup' });
    res.status(201).json({ message: 'User registered!' });
  } catch (err) {
    res.status(400).json({ error: 'Email already exists' });
  }
});

// Login endpoint
app.post('/api/login', async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email });
  let success = false;
  if (user && await bcrypt.compare(password, user.password)) {
    success = true;
    await ActivityLog.create({ email, action: 'login' });
    res.json({ message: 'Login successful', username: user.username });
  } else {
    res.status(401).json({ error: 'Invalid credentials' });
  }
});

// Logout endpoint
app.post('/api/logout', async (req, res) => {
  const { email } = req.body;
  if (!email) {
    return res.status(400).json({ error: 'Email is required for logout' });
  }
  await ActivityLog.create({ email, action: 'logout' });
  res.json({ message: 'Logout logged' });
});

// Admin registration (for initial setup, can be removed later)
app.post('/api/admin/register', async (req, res) => {
  const { email, password } = req.body;
  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const admin = new Admin({ email, password: hashedPassword });
    await admin.save();
    await AdminLoginLog.create({ adminEmail: email, action: 'register' });
    res.status(201).json({ message: 'Admin registered!' });
  } catch (err) {
    res.status(400).json({ error: 'Email already exists' });
  }
});

// Only allow this admin email
const ADMIN_EMAIL = 'admin@gmail.com'; // Change to your email if needed
const ADMIN_PASSWORD = 'venkishashu'; // Changed to new password

// Script to always upsert the admin user with the correct credentials
async function ensureInitialAdmin() {
  const passwordHash = await bcrypt.hash(ADMIN_PASSWORD, 10);
  await Admin.findOneAndUpdate(
    { email: ADMIN_EMAIL },
    { email: ADMIN_EMAIL, password: passwordHash },
    { upsert: true, new: true }
  );
}
ensureInitialAdmin();

// Admin login endpoint (restrict to only allowed email)
app.post('/api/admin/login', async (req, res) => {
  const { email, password } = req.body;
  if (email !== ADMIN_EMAIL) {
    await ActivityLog.create({ email, action: 'admin_login', details: 'Failed login (not allowed email)' });
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  try {
    const admin = await Admin.findOne({ email });
    if (!admin) {
      await ActivityLog.create({ email, action: 'admin_login', details: 'Failed login (no such user)' });
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    const isMatch = await bcrypt.compare(password, admin.password);
    if (!isMatch) {
      await ActivityLog.create({ email, action: 'admin_login', details: 'Failed login (wrong password)' });
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    await ActivityLog.create({ email, action: 'admin_login', details: 'Successful login' });
    res.json({ success: true, admin: { email: admin.email } });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Admin get all user activities
app.get('/api/admin/user-activities', async (req, res) => {
  const activities = await ActivityLog.find().sort({ timestamp: -1 });
  res.json(activities);
});

// Admin add content for users (example: add interview question)
const Question = mongoose.model('Question', new mongoose.Schema({
  question: String,
  answer: String,
  createdBy: String,
  createdAt: { type: Date, default: Date.now }
}));

app.post('/api/admin/add-question', async (req, res) => {
  const { adminEmail, question, answer } = req.body;
  const q = new Question({ question, answer, createdBy: adminEmail });
  await q.save();
  await AdminLoginLog.create({ adminEmail, action: 'add-question', details: question });
  res.json({ message: 'Question added!' });
});

// Feedback API endpoints
app.post('/api/feedback', async (req, res) => {
  try {
    const { userEmail, message, timestamp, type } = req.body;
    const feedback = new Feedback({ userEmail, message, timestamp, type });
    await feedback.save();
    await ActivityLog.create({ email: userEmail, action: 'feedback-submitted' });
    res.status(201).json({ message: 'Feedback saved successfully!' });
  } catch (error) {
    console.error('Error saving feedback:', error);
    res.status(500).json({ error: 'Failed to save feedback' });
  }
});

// Rating API endpoints
app.post('/api/rating', async (req, res) => {
  try {
    const { userEmail, rating, timestamp, type } = req.body;
    
    // Update existing rating or create new one
    await Rating.findOneAndUpdate(
      { userEmail },
      { rating, timestamp, type },
      { upsert: true, new: true }
    );
    
    await ActivityLog.create({ email: userEmail, action: 'rating-submitted', details: `${rating} stars` });
    res.status(200).json({ message: 'Rating saved successfully!' });
  } catch (error) {
    console.error('Error saving rating:', error);
    res.status(500).json({ error: 'Failed to save rating' });
  }
});

app.get('/api/rating/:userEmail', async (req, res) => {
  try {
    const { userEmail } = req.params;
    const rating = await Rating.findOne({ userEmail });
    res.json({ rating: rating ? rating.rating : 0 });
  } catch (error) {
    console.error('Error fetching rating:', error);
    res.status(500).json({ error: 'Failed to fetch rating' });
  }
});

// Get all feedback (admin endpoint)
app.get('/api/admin/feedback', async (req, res) => {
  try {
    const feedback = await Feedback.find().sort({ timestamp: -1 });
    res.json(feedback);
  } catch (error) {
    console.error('Error fetching feedback:', error);
    res.status(500).json({ error: 'Failed to fetch feedback' });
  }
});

// Get all ratings (admin endpoint)
app.get('/api/admin/ratings', async (req, res) => {
  try {
    const ratings = await Rating.find().sort({ timestamp: -1 });
    res.json(ratings);
  } catch (error) {
    console.error('Error fetching ratings:', error);
    res.status(500).json({ error: 'Failed to fetch ratings' });
  }
});

// API endpoint to receive interview submissions
app.post('/api/submit-interview', upload.single('video'), async (req, res) => {
  try {
    const { category, answers } = req.body;
    const videoFile = req.file;
    if (!category || !answers || !videoFile) {
      return res.status(400).json({ success: false, error: 'Missing data' });
    }
    // Save to MongoDB
    const interview = new Interview({
      category,
      answers: JSON.parse(answers),
      videoPath: videoFile.path
    });
    await interview.save();
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Admin get all users (including password)
app.get('/api/admin/users', async (req, res) => {
  try {
    const users = await User.find({}, { username: 1, email: 1, password: 1, _id: 0 });
    res.json(users);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch users' });
  }
});

// Serve uploaded files statically
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Add resource (PDF/Video) for a user
app.post('/api/admin/add-resource', upload.single('file'), async (req, res) => {
  try {
    const { type, title, userEmail, category } = req.body;
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
    const fileUrl = `/uploads/${req.file.filename}`;
    await Resource.create({ type, title, userEmail, category, link: fileUrl });
    res.json({ message: 'Resource added!' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to add resource.' });
  }
});

// Endpoint for user to fetch their resources
app.get('/api/user/resources', async (req, res) => {
  try {
    const { email } = req.query;
    const resources = await Resource.find({ userEmail: email });
    res.json(resources);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch resources.' });
  }
});

// Delete a resource by ID
app.delete('/api/admin/resource/:id', async (req, res) => {
  try {
    const resource = await Resource.findById(req.params.id);
    if (!resource) return res.status(404).json({ error: 'Resource not found' });
    // Remove file from uploads
    if (resource.link && resource.link.startsWith('/uploads/')) {
      const filePath = path.join(__dirname, resource.link);
      if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    }
    await Resource.deleteOne({ _id: req.params.id });
    res.json({ message: 'Resource deleted' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete resource.' });
  }
});

// Edit a resource (title and/or file)
app.put('/api/admin/resource/:id', upload.single('file'), async (req, res) => {
  try {
    const { title } = req.body;
    const update = {};
    if (title) update.title = title;
    if (req.file) {
      // Remove old file
      const resource = await Resource.findById(req.params.id);
      if (resource && resource.link && resource.link.startsWith('/uploads/')) {
        const filePath = path.join(__dirname, resource.link);
        if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
      }
      update.link = `/uploads/${req.file.filename}`;
    }
    await Resource.findByIdAndUpdate(req.params.id, update);
    res.json({ message: 'Resource updated' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update resource.' });
  }
});

// Endpoint to get user by email (for welcome message fallback)
app.get('/api/user/by-email', async (req, res) => {
  const { email } = req.query;
  if (!email) return res.status(400).json({ error: 'Email required' });
  const user = await User.findOne({ email });
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json({ username: user.username });
});

// Catch-all route for SPA - serve index.html for any unmatched routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
}); 