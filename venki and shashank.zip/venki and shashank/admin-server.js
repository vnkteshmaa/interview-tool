const express = require('express');
const path = require('path');
const cors = require('cors');
const { createProxyMiddleware } = require('http-proxy-middleware');

const app = express();
const PORT = 5000;

app.use(cors({
  origin: 'http://localhost:5000',
  credentials: true
}));
app.use(express.json());

// Proxy API requests to main backend server on port 4000
app.use('/api', createProxyMiddleware({
  target: 'http://localhost:4000',
  changeOrigin: true,
  pathRewrite: { '^/api': '/api' },
  ws: true,
}));

// Serve static files (CSS, JS, etc.)
app.use('/public', express.static(path.join(__dirname, 'public')));

// Redirect root to admin login page
app.get('/', (req, res) => {
  res.redirect('/admin-login.html');
});

// Serve admin login and home pages
app.get('/admin-login.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin-login.html'));
});
app.get('/admin-home.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin-home.html'));
});

app.listen(PORT, () => {
  console.log(`Admin server running on http://localhost:${PORT}`);
}); 